/*
 * Support.h
 *
 *  Created on: 01-Sep-2018
 *      Author: gyk31
 */

#ifndef CSUPPORT_H_
#define CSUPPORT_H_

/* XDCtools Header files */
#include <xdc/std.h>

/* BIOS Header files */

/* TI-RTOS Header files */
#include <ti/drivers/I2C.h>
#include <ti/drivers/GPIO.h>
#include <ti/drivers/SPI.h>

#include "inc/hw_memmap.h"
#include "driverlib/i2c.h"

/*Application Libraries*/
#include <libraries/PID.h>

/*Application Files*/

#include "CVertical.h"
#include "CDiagonal.h"
#include "CGlobal.h"
#include "CImu.h"


// Vertical Heights(Front and back )
#define H1 2005.0   //front
#define H2 2000.0

// Bases for hypotenus calculation
#define BASE_1  640.0
#define BASE_2  670.0
#define BASE_3  1425.0

#define VERTICAL_FRONT_SPEED_KP 1.5
#define VERTICAL_FRONT_SPEED_KI 11
#define VERTICAL_FRONT_SPEED_KD 0

#define VERTICAL_BACK_SPEED_KP 1.5
#define VERTICAL_BACK_SPEED_KI 11
#define VERTICAL_BACK_SPEED_KD 0

#define DIAGONAL_SPEED_KP 2.0
#define DIAGONAL_SPEED_KI 20.0
#define DIAGONAL_SPEED_KD 2

#define DIAGONAL_POSITION_KP 2.0
#define DIAGONAL_POSITION_KI 0.0
#define DIAGONAL_POSITION_KD 0.0

#define DIAGONAL_CURRENT_KP 0.3
#define DIAGONAL_CURRENT_KI 0.7
#define DIAGONAL_CURRENT_KD 0.0

#define DIAGONAL_TIGHTENING_KP 1.0
#define DIAGONAL_TIGHTENING_KI 5.0
#define DIAGONAL_TIGHTENING_KD 0.0

// For  IMU
#define IMU_KP  1.0
#define IMU_KI  0.0
#define IMU_KD  0.0

// PID Sample times
#define PID_SAMPLE_TIME_5_MS 5
#define PID_SAMPLE_TIME_10_MS 10

// PID Limits
#define PID_200_UPPER_LIMIT 200
#define PID_200_LOWER_LIMIT -200

#define PID_50_UPPER_LIMIT 50
#define PID_50_LOWER_LIMIT -50

#define PID_20_UPPER_LIMIT 20
#define PID_20_LOWER_LIMIT -20

#define PID_8_UPPER_LIMIT 8
#define PID_8_LOWER_LIMIT -8

// Sensor Address
#define MPU6050_I2C_ADDRESS 0x68
#define MPU6050_I2C_BASE I2C3_BASE



static const uint8_t curr_lookup[] =
    {   0, 7, 14, 20, 27 , 34, 40, 47, 53 , 60 , 66 , 72, 78, 84, 90, 96, 102, 107, 113,
        118, 123, 128, 133, 138, 142, 147, 151, 155, 159, 163, 167, 171, 174, 177, 181, 184, 187, 189, 192, 195, 197,
        200, 202, 204, 206, 208, 210, 212, 214, 215, 217, 219, 220, 221, 223, 224, 225, 226, 227, 228, 229, 230, 231,
        232, 233, 233, 234, 235, 235, 236, 237, 237, 238, 238, 239, 239, 239, 240, 240, 240, 241, 241, 241, 242, 242,
        242, 242, 243, 243, 243, 243, 243, 243, 243, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
        244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
        244, 244, 244, 244, 244, 244, 244, 244, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243,
        243, 243, 243, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 241, 241, 241,
        241, 241, 241, 241, 241, 241, 241, 241, 241, 241, 241, 241, 241, 241, 241, 240, 240, 240, 240, 240, 240, 240,
        240, 240, 240, 240, 240, 240, 240, 240, 240, 240, 240, 240, 239, 239, 239, 239, 239, 239, 239, 239, 239, 239,
        239, 239, 239, 239, 239, 239, 239, 239, 239, 239, 239, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238,
        238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 237, 237, 237, 237, 237, 237,
        237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237,
        237, 237, 237, 237, 237, 236, 236, 236, 236, 236, 236, 236, 236, 236, 236, 236, 236
    };
typedef struct i2cTransferParams{
    uint8_t slaveAddress;
    uint16_t regAddress;
    uint16_t value;
    size_t length;
    bool is8bitTransfer;
    bool isChannel1;
}i2cTransferParams;


typedef enum I2C_TRANSFER_TYPE{
    IMU_TRANSACTION,
    CURRENT_TRANSACTION
}I2C_TRANSFER_TYPE;
class CSupport
{
public:
    static const uint8_t curr_lookup[];
public:
    CSupport();
    uint8_t lookUp_curr_Setpoint(int16_t sp);
    void i2c_writeRegister(I2C_Handle handle,
                           unsigned char slaveAddr,
                           uint16_t regAddr,
                           uint32_t value,
                           I2C_TRANSFER_TYPE transferType);
    void i2c_readRegister(I2C_Handle handle,
                          unsigned char slaveAddr,
                          uint16_t regAddr,
                          uint16_t *data,
                          size_t   length,
                          I2C_TRANSFER_TYPE transferType);

   void setPIDSampleTime(CGlobal* );
   /*     void setPIDMode(CGlobal*,int);
    void pidReset(CGlobal* );*/
/*    void writeRegister(I2C_Handle handle, uint16_t regAddr, uint16_t value);
    void readRegister(I2C_Handle handle, uint16_t regAddr, uint8_t *data,size_t length);*/
};
#endif /* CSUPPORT_H_ */
