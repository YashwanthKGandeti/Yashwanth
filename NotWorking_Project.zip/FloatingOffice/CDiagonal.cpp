/*
 * CDiagonal.cpp
 *
 *  Created on: 28-Aug-2018
 *      Author: Yashwanth Kumar Gandeti
 */

/* TI-RTOS Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/I2C.h>
#include <ti/drivers/PWM.h>

/* Driver Libraries */
#include "inc/hw_gpio.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"

/*System Libraries*/
#include <math.h>

/*Application Files*/
#include "CDiagonal.h"

CDiagonal::CDiagonal(float height,float base)
{

}
CDiagonal::CDiagonal(){

}

void diagonalInit()
{
    /***********************************Diagonal - Hall Input Pin Definitions********************************************/

    //
    // Configure the GPIO Pin Mux for PA0
    // for GPIO_PA0 - Diagonal 1 Hall Input
    //
    GPIOPinTypeGPIOInput(GPIO_PORTA_BASE, GPIO_PIN_0);
    GPIOPadConfigSet(GPIO_PORTA_BASE, GPIO_PIN_0, GPIO_STRENGTH_2MA,
    GPIO_PIN_TYPE_STD_WPU);

    //
    // Configure the GPIO Pin Mux for PA1
    // for GPIO_PA1 - Diagonal 2 Hall Input
    //
    GPIOPinTypeGPIOInput(GPIO_PORTA_BASE, GPIO_PIN_1);
    GPIOPadConfigSet(GPIO_PORTA_BASE, GPIO_PIN_1, GPIO_STRENGTH_2MA,
    GPIO_PIN_TYPE_STD_WPU);

    //
    // Configure the GPIO Pin Mux for PA2
    // for GPIO_PA2 - Diagonal 3 Hall Input
    //
    GPIOPinTypeGPIOInput(GPIO_PORTA_BASE, GPIO_PIN_2);
    GPIOPadConfigSet(GPIO_PORTA_BASE, GPIO_PIN_2, GPIO_STRENGTH_2MA,
    GPIO_PIN_TYPE_STD_WPU);

    //
    // Configure the GPIO Pin Mux for PA3
    // for GPIO_PA3 - Diagonal 4 Hall Input
    //
    GPIOPinTypeGPIOInput(GPIO_PORTA_BASE, GPIO_PIN_3);
    GPIOPadConfigSet(GPIO_PORTA_BASE, GPIO_PIN_3, GPIO_STRENGTH_2MA,
    GPIO_PIN_TYPE_STD_WPU);

    //
    // Configure the GPIO Pin Mux for PA4
    // for GPIO_PA4 - Diagonal 5 Hall Input
    //
    GPIOPinTypeGPIOInput(GPIO_PORTA_BASE, GPIO_PIN_4);
    GPIOPadConfigSet(GPIO_PORTA_BASE, GPIO_PIN_4, GPIO_STRENGTH_2MA,
    GPIO_PIN_TYPE_STD_WPU);

    //
    // Configure the GPIO Pin Mux for PA5
    // for GPIO_PA5 - Diagonal 6 Hall Input
    //
    GPIOPinTypeGPIOInput(GPIO_PORTA_BASE, GPIO_PIN_5);
    GPIOPadConfigSet(GPIO_PORTA_BASE, GPIO_PIN_5, GPIO_STRENGTH_2MA,
    GPIO_PIN_TYPE_STD_WPU);

    /***********************************Diagonal - Direction Pin Definitions********************************************/

    //
    // Configure the GPIO Pin Mux for PD4
    // for GPIO_PD4 - Diagonal Direction 1
    //
    GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_4);
    GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_4, GPIO_PIN_4);

    //
    // Configure the GPIO Pin Mux for PD5
    // for GPIO_PD5 - Diagonal Direction 2
    //
    GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_5);
    GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_5, GPIO_PIN_5);

    //
    // Configure the GPIO Pin Mux for PB1
    // for GPIO_PB1
    //
    GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_1);
    GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_1, GPIO_PIN_1);

    //
    // Configure the GPIO Pin Mux for PD6
    // for GPIO_PD6 - Diagonal Direction 4
    //
    GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_6);
    GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_6, GPIO_PIN_6);

    //
    // Configure the GPIO Pin Mux for PD0
    // for GPIO_PD0 - Diagonal Direction 5
    //
    GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_0);
    GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_0, GPIO_PIN_0);

    //
    // Configure the GPIO Pin Mux for PD1
    // for GPIO_PD1 - Diagonal Direction 6
    //
    GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_1);
    GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, GPIO_PIN_1);




    /***********************************Diagonal - PWM Pin Definitions********************************************/
    //
    // Configure the GPIO Pin Mux for PB4
    // for M0PWM2 - Diagonal 1 PWM
    //
    GPIOPinConfigure(GPIO_PB4_M0PWM2);
    GPIOPinTypePWM(GPIO_PORTB_BASE, GPIO_PIN_4);

    //
    // Configure the GPIO Pin Mux for PB5
    // for M0PWM3  - Diagonal 2 PWM
    //
    GPIOPinConfigure(GPIO_PB5_M0PWM3);
    GPIOPinTypePWM(GPIO_PORTB_BASE, GPIO_PIN_5);

    //
    // Configure the GPIO Pin Mux for PE4
    // for M0PWM4  - Diagonal 3 PWM
    //
    GPIOPinConfigure(GPIO_PE4_M0PWM4);
    GPIOPinTypePWM(GPIO_PORTE_BASE, GPIO_PIN_4);

    //
    // Configure the GPIO Pin Mux for PE5
    // for M0PWM5  - Diagonal 4 PWM
    //
    GPIOPinConfigure(GPIO_PE5_M0PWM5);
    GPIOPinTypePWM(GPIO_PORTE_BASE, GPIO_PIN_5);

    //
    // Configure the GPIO Pin Mux for PC4
    // for M0PWM6  - Diagonal 5 PWM
    //
    GPIOPinConfigure(GPIO_PC4_M0PWM6);
    GPIOPinTypePWM(GPIO_PORTC_BASE, GPIO_PIN_4);

    //
    // Configure the GPIO Pin Mux for PC5
    // for M0PWM7  - Diagonal 6 PWM
    //
    GPIOPinConfigure(GPIO_PC5_M0PWM7);
    GPIOPinTypePWM(GPIO_PORTC_BASE, GPIO_PIN_5);

    PWM_init();

}
void i2cInit()
{
    /* I2C0 Init */
    /* Enable the peripheral */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C0);

    // Configure the GPIO Pin Mux for PB2 for I2C0SCL

    GPIOPinConfigure(GPIO_PB2_I2C0SCL);
    GPIOPinTypeI2CSCL(GPIO_PORTB_BASE, GPIO_PIN_2);

    // Configure the GPIO Pin Mux for PB3 for I2C0SDA

    GPIOPinConfigure(GPIO_PB3_I2C0SDA);
    GPIOPinTypeI2C(GPIO_PORTB_BASE, GPIO_PIN_3);

    /* I2C1 Init */
    /* Enable the peripheral */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C1);

    // Configure the GPIO Pin Mux for PA6 for I2C1SCL

    GPIOPinConfigure(GPIO_PA6_I2C1SCL);
    GPIOPinTypeI2CSCL(GPIO_PORTA_BASE, GPIO_PIN_6);

    // Configure the GPIO Pin Mux for PA7 for I2C1SDA

    GPIOPinConfigure(GPIO_PA7_I2C1SDA);
    GPIOPinTypeI2C(GPIO_PORTA_BASE, GPIO_PIN_7);

    I2C_init();
}

void CDiagonal::initDiagonal(float height, float base)
{
    this->speedKp = DIAGONAL_SPEED_KP;
    this->speedKi = DIAGONAL_SPEED_KI;
    this->positionKp = DIAGONAL_POSITION_KP;
    this->currentKp = DIAGONAL_CURRENT_KP;
    this->currentKi = DIAGONAL_CURRENT_KI;
    this->tensionKp = DIAGONAL_TIGHTENING_KP;
    this->tensionKi = DIAGONAL_TIGHTENING_KI;
    this->h_0 = sqrtf((height * height + base * base)); // Hypotenus calculation
}
