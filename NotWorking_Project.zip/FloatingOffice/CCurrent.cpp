/*
 * CCurrent.cpp
 *
 *  Created on: 02-Jan-2019
 *      Author: Yashwanth Kumar Gandeti
 */

#include <CCurrent.h>

CCurrent::CCurrent(const int addr):ina(addr){
}
void CCurrent::init(I2C_Handle *i2cChannel){
    ina.setCalibration_32V_2A(i2cChannel);// Sets calibration
    for (int i = 0; i < 100; i++) {
    current = ina.getCurrent_mA(i2cChannel);
    current_filt = 0.95 * current_filt + 0.05 * current;
    //Task_sleep(5);
    }
    current_offset = current_filt;
}

void CCurrent::compute(I2C_Handle *i2cChannel,double * input){
    current=ina.getCurrent_mA(i2cChannel)-current_offset;
    current_filt=current_filt*alpha+current*(1-alpha);
    *input = get_current();

}
