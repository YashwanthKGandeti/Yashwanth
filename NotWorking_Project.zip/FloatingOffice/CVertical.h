/*
 * CVertical.h
 *
 *  Created on: 28-Aug-2018
 *      Author: Yashwanth Kumar Gandeti
 */

#ifndef CVERTICAL_H_
#define CVERTICAL_H_
#include <xdc/std.h>
#include <xdc/runtime/System.h>

// Vertical Heights(Front and back )
#define H1 2005.0   //front
#define H2 2000.0

class CVertical
{
public :
    // PID control params (Speed)
    double speedKp;
    double speedKi;
    double speedKd;

    double speedSetpoint;
    double speedInput;
    double speedOutput;

    // Direction pins
    int pinA;
    int pinB;

    int   pwmPin;  // pwm pin

    float rpm;          // Rpm
    float rpmFiltered;  // Rpm filtered

    int16_t encPos;         // Encoder position
    int16_t encPosOld;
    int16_t encPosOffset;

    float vertUpdHeight;      // Update vertical height in mm
    float vertIntHeight;      // intial vertical height in mm before start

public :
    CVertical();
    CVertical(double kp, double ki,float initHeight);
    void initVertical(double kp, double ki,float initHeight);


};
extern "C" void verticalInit();
#endif /* CVERTICAL_H_ */
