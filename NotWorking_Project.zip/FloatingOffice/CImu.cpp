/*
 * CImu.cpp
 *
 *  Created on: 06-Sep-2018
 *      Author: gyk31
 */

#include "CImu.h"
CImu::CImu(){

}
CImu::CImu(float kp,float ki, float kd)
{
this->imuInput=0.0;
this->imuOutput=0.0;
this->imuSetpoint=0.0;
this->imuKp = kp;
this->imuKi = ki;
this->imuKd = kd;
}
