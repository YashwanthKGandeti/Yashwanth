/*
 * CGlobal.h
 *
 *  Created on: 29-Oct-2018
 *      Author: Yashwanth Kumar Gandeti
 */

#ifndef CGLOBAL_H_
#define CGLOBAL_H_

/*Application Libraries*/
#include <libraries/PID.h>

/* TI-RTOS Header files */
#include <ti/drivers/I2C.h>
#include <ti/drivers/GPIO.h>

#include "inc/hw_memmap.h"
#include "driverlib/i2c.h"

/*Application Files*/
//#include "CSupport.h"
#include "CVertical.h"
#include "CDiagonal.h"
#include "CImu.h"

/*
                                                                        BACK
                                             ***********************************************************
                                             *   5                                                6    *
                                             * 3                                                     1 *
                                             *                                                         *
                                             *                                                         *
                                             *                                                         *
                                    LEFT     *                                                         *    RIGHT
                                             *                                                         *
                                             *                                                         *
                                             *                                                         *
                                             * 4                                                     2 *
                                             *                                                         *
                                             ***********************************************************
                                                                        FRONT
 */

class CGlobal
{

public:
    CVertical front;
    CVertical back;

    CDiagonal dia1;
    CDiagonal dia2;
    CDiagonal dia3;
    CDiagonal dia4;
    CDiagonal dia5;
    CDiagonal dia6;

    CImu imu;
    // PID Controllers for Vertical movement
    PID frontRpmController;
    PID backRpmController;

    // PID Controllers for Diagonal 1  ===>  Right Back
    PID dia1RpmController;
    PID dia1PosController;
    PID dia1CurrController;
    PID dia1TensionController;

    // PID Controllers for Diagonal 2  ===> Right Front

    PID dia2RpmController;
    PID dia2PosController;
    PID dia2CurrController;
    PID dia2TensionController;

    // PID Controllers for Diagonal 3  ===> Left Back

    PID dia3RpmController;
    PID dia3PosController;
    PID dia3CurrController;
    PID dia3TensionController;

    // PID Controllers for Diagonal 4 ===> Left Front

    PID dia4RpmController;
    PID dia4PosController;
    PID dia4CurrController;
    PID dia4TensionController;

    // PID Controllers for Diagonal 5 ====> Back Left

    PID dia5RpmController;
    PID dia5PosController;
    PID dia5CurrController;
    PID dia5TensionController;

    // PID Controllers for Diagonal 6 ===> Back Right

    PID dia6RpmController;
    PID dia6PosController;
    PID dia6CurrController;
    PID dia6TensionController;

    // PID Controller for IMU
    PID imuController;

public:
    CGlobal();
/*    void writeRegister(I2C_Handle handle, uint16_t regAddr, uint16_t value);
    void readRegister(I2C_Handle handle, uint16_t regAddr, uint8_t *data,size_t length);*/

};

#endif /* CGLOBAL_H_ */
