/*
 * Support.cpp
 *
 *  Created on: 01-Sep-2018
 *      Author: Yashwanth Kumar Gandeti
 */
#include "CSupport.h"

CSupport::CSupport()
{

}
uint8_t CSupport::lookUp_curr_Setpoint(int16_t sp)
{
    sp = curr_lookup[sp];
    return sp;
}

void CSupport::setPIDSampleTime(CGlobal* obj)
{
    //Vertical
    obj->frontRpmController.SetOutputLimits(PID_200_LOWER_LIMIT,
                                            PID_200_UPPER_LIMIT);

    obj->backRpmController.SetOutputLimits(PID_200_LOWER_LIMIT,
                                           PID_200_UPPER_LIMIT);

    //Diagonal 1
    obj->dia1RpmController.SetOutputLimits(PID_200_LOWER_LIMIT,
                                           PID_200_UPPER_LIMIT);

    obj->dia1PosController.SetOutputLimits(PID_20_LOWER_LIMIT,
                                           PID_20_UPPER_LIMIT);

    obj->dia1CurrController.SetOutputLimits(PID_20_LOWER_LIMIT,
                                            PID_20_UPPER_LIMIT);

    obj->dia1TensionController.SetOutputLimits(PID_200_LOWER_LIMIT,
                                               PID_200_UPPER_LIMIT);

    //Diagonal 2
    obj->dia2RpmController.SetOutputLimits(PID_200_LOWER_LIMIT,
                                           PID_200_UPPER_LIMIT);

    obj->dia2PosController.SetOutputLimits(PID_20_LOWER_LIMIT,
                                           PID_20_UPPER_LIMIT);

    obj->dia2CurrController.SetOutputLimits(PID_50_LOWER_LIMIT,
                                            PID_50_UPPER_LIMIT);

    obj->dia2TensionController.SetOutputLimits(PID_200_LOWER_LIMIT,
                                               PID_200_UPPER_LIMIT);

    //Diagonal 3
    obj->dia3RpmController.SetOutputLimits(PID_200_LOWER_LIMIT,
                                           PID_200_UPPER_LIMIT);

    obj->dia3PosController.SetOutputLimits(PID_20_LOWER_LIMIT,
                                           PID_20_UPPER_LIMIT);

    obj->dia3CurrController.SetOutputLimits(PID_50_LOWER_LIMIT,
                                            PID_50_UPPER_LIMIT);

    obj->dia3TensionController.SetOutputLimits(PID_200_LOWER_LIMIT,
                                               PID_200_UPPER_LIMIT);

    //Diagonal 4
    obj->dia4RpmController.SetOutputLimits(PID_200_LOWER_LIMIT,
                                           PID_200_UPPER_LIMIT);

    obj->dia4PosController.SetOutputLimits(PID_20_LOWER_LIMIT,
                                           PID_20_UPPER_LIMIT);

    obj->dia4CurrController.SetOutputLimits(PID_50_LOWER_LIMIT,
                                            PID_50_UPPER_LIMIT);

    obj->dia4TensionController.SetOutputLimits(PID_200_LOWER_LIMIT,
                                               PID_200_UPPER_LIMIT);

    //Diagonal 5
    obj->dia5RpmController.SetOutputLimits(PID_200_LOWER_LIMIT,
                                           PID_200_UPPER_LIMIT);

    obj->dia5PosController.SetOutputLimits(PID_20_LOWER_LIMIT,
                                           PID_20_UPPER_LIMIT);

    obj->dia5CurrController.SetOutputLimits(PID_50_LOWER_LIMIT,
                                            PID_50_UPPER_LIMIT);

    obj->dia5TensionController.SetOutputLimits(PID_200_LOWER_LIMIT,
                                               PID_200_UPPER_LIMIT);

    //Diagonal 6
    obj->dia6RpmController.SetOutputLimits(PID_200_LOWER_LIMIT,
                                           PID_200_UPPER_LIMIT);

    obj->dia6PosController.SetOutputLimits(PID_20_LOWER_LIMIT,
                                           PID_20_UPPER_LIMIT);

    obj->dia6CurrController.SetOutputLimits(PID_20_LOWER_LIMIT,
                                            PID_20_UPPER_LIMIT);

    obj->dia6TensionController.SetOutputLimits(PID_200_LOWER_LIMIT,
                                               PID_200_UPPER_LIMIT);

    //Imu
    obj->imuController.SetOutputLimits(PID_8_LOWER_LIMIT, PID_8_UPPER_LIMIT);
}

/*void CSupport::setPIDMode(CGlobal* obj,int mode)
{
    obj->frontRpmController.SetMode(mode);

    obj->backRpmController.SetMode(mode);

    Diagonal 1
    obj->dia1RpmController.SetMode(mode);

    obj->dia1PosController.SetMode(mode);

    obj->dia1CurrController.SetMode(mode);

    obj->dia1TensionController.SetMode(mode);

    Diagonal 2
    obj->dia2RpmController.SetMode(mode);

    obj->dia2PosController.SetMode(mode);

    obj->dia2CurrController.SetMode(mode);

    obj->dia2TensionController.SetMode(mode);

    Diagonal 3
    obj->dia3RpmController.SetMode(mode);

    obj->dia3PosController.SetMode(mode);

    obj->dia3CurrController.SetMode(mode);

    obj->dia3TensionController.SetMode(mode);

    Diagonal 4
    obj->dia4RpmController.SetMode(mode);

    obj->dia4PosController.SetMode(mode);

    obj->dia4CurrController.SetMode(mode);

    obj->dia4TensionController.SetMode(mode);

    Diagonal 5
    obj->dia5RpmController.SetMode(mode);

    obj->dia5PosController.SetMode(mode);

    obj->dia5CurrController.SetMode(mode);

    obj->dia5TensionController.SetMode(mode);

    Diagonal 6
    obj->dia6RpmController.SetMode(mode);

    obj->dia6PosController.SetMode(mode);

    obj->dia6CurrController.SetMode(mode);

    obj->dia6TensionController.SetMode(mode);

    Imu
    obj->imuController.SetMode(mode);
}

void CSupport::pidReset(CGlobal* obj)
{
    obj->frontRpmController.reset();

    obj->backRpmController.reset();

    Diagonal 1
    obj->dia1RpmController.reset();

    obj->dia1PosController.reset();

    obj->dia1CurrController.reset();

    obj->dia1TensionController.reset();

    Diagonal 2
    obj->dia2RpmController.reset();

    obj->dia2PosController.reset();

    obj->dia2CurrController.reset();

    obj->dia2TensionController.reset();

    Diagonal 3
    obj->dia3RpmController.reset();

    obj->dia3PosController.reset();

    obj->dia3CurrController.reset();

    obj->dia3TensionController.reset();

    Diagonal 4
    obj->dia4RpmController.reset();

    obj->dia4PosController.reset();

    obj->dia4CurrController.reset();

    obj->dia4TensionController.reset();

    Diagonal 5
    obj->dia5RpmController.reset();

    obj->dia5PosController.reset();

    obj->dia5CurrController.reset();

    obj->dia5TensionController.reset();

    Diagonal 6
    obj->dia6RpmController.reset();

    obj->dia6PosController.reset();

    obj->dia6CurrController.reset();

    obj->dia6TensionController.reset();

    Imu
    obj->imuController.reset();
}*/

/*
This function used for write operation in I2C Transaction of 8 and 16 bit registers
for 8  bit transaction - is8bitTransfer is true
for 16 bit transaction - is8bitTransfer is false
*/

void CSupport::i2c_writeRegister(I2C_Handle handle,unsigned char slaveAddr,uint16_t regAddr, uint32_t value,I2C_TRANSFER_TYPE transferType)
{

    I2C_Handle  i2cChannel1;
    I2C_Params currI2cParams;

    uint8_t             txBuffer[4];
    I2C_Transaction     i2cTransaction;

    i2cTransaction.slaveAddress = slaveAddr;
    i2cTransaction.writeBuf = txBuffer;

    switch(transferType)
    {
        case IMU_TRANSACTION :
        //Write to a 8-bit status register
        i2cTransaction.writeCount = 2;
        i2cTransaction.readCount = 0;

        txBuffer[0] = regAddr & 0xFF;//LB Addr
        txBuffer[1] = value & 0xFF;
        break;
        case CURRENT_TRANSACTION :

        i2cTransaction.writeCount = 3;
        i2cTransaction.readCount = 0;

        txBuffer[0] = regAddr & 0xFF;// 8- Bit address
        txBuffer[1] = value >> 8;// HB Addr
        txBuffer[2] = value & 0xFF;// LB Addr
        break;

        default:

        //Write to a 16-bit status register
        i2cTransaction.writeCount = 4;
        i2cTransaction.readCount = 0;

        txBuffer[0] = (regAddr >> 8) & 0xFF;//HB Addr
        txBuffer[1] = regAddr & 0xFF;//LB Addr
        txBuffer[2] = value & 0xFF;
        txBuffer[3] = (value >> 8) & 0xFF;
        break;

    }

    if (!I2C_transfer(handle, &i2cTransaction)) {
        GPIO_write(Board_LED_RED, Board_LED_ON);
        System_abort("Bad I2C transfer!");
    }
}

/*
This function used for read operation in I2C Transaction of 8 and 16 bit registers
for 8  bit transaction - is8bitTransfer is true
for 16 bit transaction - is8bitTransfer is false
*/

void CSupport::i2c_readRegister(I2C_Handle handle, unsigned char slaveAddr,
                                uint16_t regAddr, uint16_t *data, size_t length,
                                I2C_TRANSFER_TYPE transferType)
{
    uint8_t             txBuffer[2];
    I2C_Transaction     i2cTransaction;

    i2cTransaction.slaveAddress = slaveAddr;
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.readBuf = data;
    i2cTransaction.readCount = length;


    switch(transferType)
    {
        case IMU_TRANSACTION :
        //Write to a 8-bit status register
        i2cTransaction.writeCount = 1;
        txBuffer[0] = regAddr & 0xFF;//LB Addr
        break;
        case CURRENT_TRANSACTION :
        i2cTransaction.writeCount = 1;
        txBuffer[0] = regAddr & 0xFF;// 8- Bit address
        break;
        default: // 16- Bit address
        i2cTransaction.writeCount = 2;
        txBuffer[0] = regAddr >> 8;//HB Addr
        txBuffer[1] = regAddr & 0xFF;//LB Addr
        break;

    }

/*    if (is8bitTransfer)
    {  //Write to a 8-bit status register
        i2cTransaction.writeCount = 1;
        txBuffer[0] = regAddr & 0xFF; //LB Addr
    }
    else
    {   //Write to a 16-bit status register
        i2cTransaction.writeCount = 2;
        txBuffer[0] = regAddr >> 8;   //HB Addr
        txBuffer[1] = regAddr & 0xFF; //LB Addr
    }*/
    if (!I2C_transfer(handle, &i2cTransaction)) {
        /*GPIO_write(Board_LED_RED, Board_LED_ON);*/
        System_abort("Bad I2C transfer!");
    }
}

