/*
 * CCurrent.h
 *
 *  Created on: 02-Jan-2019
 *      Author: HP
 */

#ifndef CCURRENT_H_
#define CCURRENT_H_

/* BIOS Header files */
#include <ti/sysbios/knl/Task.h>

/* TI-RTOS Header files */
#include <ti/drivers/I2C.h>

/* Library files*/
#include <libraries/INA219_wire.h>

/*Application Files*/
#include "CSupport.h"
class CCurrent
{

private:
    INA219_wire ina;
    float current;
    float current_filt;
    float current_offset;
    float alpha = 0.95; //filter coefficient low pass

public:
    CCurrent(const int addr);
    float get_current(){return current_filt;}
    float get_current_unfiltered(){return current;}
    void compute(I2C_Handle*, double*);
    void init(I2C_Handle*);


};

#endif /* CCURRENT_H_ */
