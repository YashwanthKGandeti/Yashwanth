/*
 * CImplementation.h
 *
 *  Created on: 29-Oct-2018
 *      Author: Yashwanth Kumar Gandeti
 */

#ifndef CIMPLEMENTATION_H_
#define CIMPLEMENTATION_H_

/* XDCtools Header files */
#include <CGlobal.h>
#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Log.h>                //needed for any Log_info() call
#include <xdc/cfg/global.h>                 //header file for statically defined objects/handles
#include <xdc/runtime/Timestamp.h>          //for timestampping

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Clock.h>


#include <stdint.h>
#include <stdbool.h>

/* TI-RTOS Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/I2C.h>
// #include <ti/drivers/SDSPI.h>
// #include <ti/drivers/SPI.h>
// #include <ti/drivers/UART.h>
// #include <ti/drivers/Watchdog.h>
// #include <ti/drivers/WiFi.h>

/* Board Header file */
#include "Board.h"
#include "inc/hw_gpio.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/i2c.h"

/* Library files*/
#include <libraries/PID.h>
#include <libraries/INA219_wire.h>


/*Application Files*/
#include "CGlobal.h"
#include "CSupport.h"
#include "CVertical.h"
#include "CDiagonal.h"
#include "CImu.h"


/*
 *  ======== Declare Threads ========
 *  Declare all threads(Hwi,Swi,Task,Idle Task) with in extern "C" before defining them.
 *
 */


class CImplementation
{
public:


};

#endif /* CIMPLEMENTATION_H_ */
