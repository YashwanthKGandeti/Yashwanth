/*
 * CImu.h
 *
 *  Created on: 06-Sep-2018
 *      Author: gyk31
 */

#ifndef CIMU_H_
#define CIMU_H_
#include <xdc/std.h>

class CImu
{
public:
    double imuInput;
    double imuOutput;
    double imuSetpoint;
    double imuKp;
    double imuKi;
    double imuKd;
    struct MPU6050
    {
        uint8_t AccelXH;
        uint8_t AccelXL;
        uint8_t AccelYH;
        uint8_t AccelYL;
        uint8_t AccelZH;
        uint8_t AccelZL;
        uint8_t TempH;
        uint8_t TempL;
        uint8_t GyroXH;
        uint8_t GyroXL;
        uint8_t GyroYH;
        uint8_t GyroYL;
        uint8_t GyroZH;
        uint8_t GyroZL;
    } mpu6050;
public:
    CImu();
    CImu(float,float,float);
    bool imuInit();
};

#endif /* CIMU_H_ */
