/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-B24
 */

#ifndef xconfig_floatingOffice__
#define xconfig_floatingOffice__



#endif /* xconfig_floatingOffice__ */ 
