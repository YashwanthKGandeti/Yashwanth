/*
 * Test.cpp
 *
 *  Created on: 29-Oct-2018
 *      Author: HP
 */

#include <CGlobal.h>

CGlobal :: CGlobal (){

this->front.initVertical(VERTICAL_FRONT_SPEED_KP, VERTICAL_FRONT_SPEED_KI, H1);
this->back.initVertical(VERTICAL_BACK_SPEED_KP, VERTICAL_BACK_SPEED_KI, H2);

this->dia1.initDiagonal(back.vertIntHeight, BASE_1);
this->dia2.initDiagonal(front.vertIntHeight, BASE_2);
this->dia3.initDiagonal(back.vertIntHeight, BASE_1);
this->dia4.initDiagonal(front.vertIntHeight, BASE_2);
this->dia5.initDiagonal(back.vertIntHeight, BASE_3);
this->dia6.initDiagonal(back.vertIntHeight, BASE_3);

//PID Controllers for Verticals

this->frontRpmController.initPID(&front.speedInput, &front.speedOutput,
                           &front.speedSetpoint, front.speedKp, front.speedKi,front.speedKd, DIRECT);

this->backRpmController.initPID(&back.speedInput, &back.speedOutput, &back.speedSetpoint,
                        back.speedKp, back.speedKi, back.speedKd, DIRECT);

// PID Controllers for Diagonal 1  ===> Right Back

this->dia1RpmController.initPID(&dia1.speedInput, &dia1.speedOutput,
                                &dia1.speedSetpoint, dia1.speedKp, dia1.speedKi,dia1.speedKd, DIRECT);

this->dia1PosController.initPID(&dia1.positionInput, &dia1.positionOutput,
                                &dia1.positionSetpoint, dia1.positionKp,dia1.positionKi, dia1.positionKd, DIRECT);

this->dia1CurrController.initPID(&dia1.currentInput, &dia1.currentOutput,
                                 &dia1.currentSetpoint, dia1.currentKp,dia1.currentKi, dia1.currentKd, DIRECT);

this->dia1TensionController.initPID(&dia1.tensionInput, &dia1.tensionOutput,
                                    &dia1.tensionSetpoint, dia1.tensionKp,dia1.tensionKi, dia1.tensionKd, DIRECT);

// PID Controllers for Diagonal 2  ===> Right Front

this->dia2RpmController.initPID(&dia2.speedInput, &dia2.speedOutput,
                                &dia2.speedSetpoint, dia2.speedKp, dia2.speedKi,dia2.speedKd, DIRECT);

this->dia2PosController.initPID(&dia2.positionInput, &dia2.positionOutput,
                                &dia2.positionSetpoint, dia2.positionKp,dia2.positionKi, dia2.positionKd, DIRECT);

this->dia2CurrController.initPID(&dia2.currentInput, &dia2.currentOutput,
                                 &dia2.currentSetpoint, dia2.currentKp,dia2.currentKi, dia2.currentKd, DIRECT);

this->dia2TensionController.initPID(&dia2.tensionInput, &dia2.tensionOutput,
                                    &dia2.tensionSetpoint, dia2.tensionKp,dia2.tensionKi, dia2.tensionKd, DIRECT);

//PID Controllers for Diagonal 3  ===> Left Back

this->dia3RpmController.initPID(&dia3.speedInput, &dia3.speedOutput,
                                &dia3.speedSetpoint, dia3.speedKp, dia3.speedKi,dia3.speedKd, DIRECT);

this->dia3PosController.initPID(&dia3.positionInput, &dia3.positionOutput,
                                &dia3.positionSetpoint, dia3.positionKp,dia3.positionKi, dia3.positionKd, DIRECT);

this->dia3CurrController.initPID(&dia3.currentInput, &dia3.currentOutput,
                                 &dia3.currentSetpoint, dia3.currentKp,dia3.currentKi, dia3.currentKd, DIRECT);

this->dia3TensionController.initPID(&dia3.tensionInput, &dia3.tensionOutput,
                                    &dia3.tensionSetpoint, dia3.tensionKp,dia3.tensionKi, dia3.tensionKd, DIRECT);

//PID Controllers for Diagonal 4 ===> Left Front

this->dia4RpmController.initPID(&dia4.speedInput, &dia4.speedOutput,
                                &dia4.speedSetpoint, dia4.speedKp, dia4.speedKi,dia4.speedKd, DIRECT);

this->dia4PosController.initPID(&dia4.positionInput, &dia4.positionOutput,
                                &dia4.positionSetpoint, dia4.positionKp,dia4.positionKi, dia4.positionKd, DIRECT);

this->dia4CurrController.initPID(&dia4.currentInput, &dia4.currentOutput,
                                 &dia4.currentSetpoint, dia4.currentKp,dia4.currentKi, dia4.currentKd, DIRECT);

this->dia4TensionController.initPID(&dia4.tensionInput, &dia4.tensionOutput,
                                    &dia4.tensionSetpoint, dia4.tensionKp,dia4.tensionKi, dia4.tensionKd, DIRECT);

//PID Controllers for Diagonal 5 ====> Back Left

this->dia5RpmController.initPID(&dia5.speedInput, &dia5.speedOutput,
                                &dia5.speedSetpoint, dia5.speedKp, dia5.speedKi,dia5.speedKd, DIRECT);

this->dia5PosController.initPID(&dia5.positionInput, &dia5.positionOutput,
                                &dia5.positionSetpoint, dia5.positionKp,dia5.positionKi, dia5.positionKd, DIRECT);

this->dia5CurrController.initPID(&dia5.currentInput, &dia5.currentOutput,
                                 &dia5.currentSetpoint, dia5.currentKp,dia5.currentKi, dia5.currentKd, DIRECT);

this->dia5TensionController.initPID(&dia5.tensionInput, &dia5.tensionOutput,
                                    &dia5.tensionSetpoint, dia5.tensionKp,dia5.tensionKi, dia5.tensionKd, DIRECT);

//PID Controllers for Diagonal 6 ===> Back Right

this->dia6RpmController.initPID(&dia6.speedInput, &dia6.speedOutput,
                                &dia6.speedSetpoint, dia6.speedKp, dia6.speedKi,dia6.speedKd, DIRECT);

this->dia6PosController.initPID(&dia6.positionInput, &dia6.positionOutput,
                                &dia6.positionSetpoint, dia6.positionKp,dia6.positionKi, dia6.positionKd, DIRECT);

this->dia6CurrController.initPID(&dia6.currentInput, &dia6.currentOutput,
                                 &dia6.currentSetpoint, dia6.currentKp,dia6.currentKi, dia6.currentKd, DIRECT);

this->dia6TensionController.initPID(&dia6.tensionInput, &dia6.tensionOutput,
                                    &dia6.tensionSetpoint, dia6.tensionKp,dia6.tensionKi, dia6.tensionKd, DIRECT);

//PID Controller for IMU
this->imuController.initPID(&imu.imuInput, &imu.imuOutput, &imu.imuSetpoint, imu.imuKp,
                      imu.imuKi, imu.imuKd, DIRECT);
}

/*// This function used for I2C Transaction of MPU-6050 register addresses and commands are 8 bit, not 16 bit

void CGlobal::writeRegister(I2C_Handle handle, uint16_t regAddr, uint16_t value)
{
    uint8_t             txBuffer[4];
    I2C_Transaction     i2cTransaction;

    i2cTransaction.slaveAddress = MPU6050_I2C_ADDRESS;

     //Write to a 16-bit status register
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 2;
    i2cTransaction.readCount = 0;

    txBuffer[0] = regAddr & 0xFF; //LB Addr
    txBuffer[1] = value   & 0xFF;

    if (!I2C_transfer(handle, &i2cTransaction)) {
        GPIO_write(Board_LED_RED, Board_LED_ON);
        System_abort("Bad I2C transfer!");
    }
}

// This function used for I2C Transaction of MPU-6050 register addresses and commands are 8 bit, not 16 bit

void CGlobal::readRegister(I2C_Handle handle,
                  uint16_t regAddr,
                  uint8_t *data,
                  size_t   length)
{
    uint8_t             txBuffer[2];
    I2C_Transaction     i2cTransaction;

    i2cTransaction.slaveAddress = MPU6050_I2C_ADDRESS;

     //Write to a 16-bit status register
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.readBuf = data;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readCount = length;

    txBuffer[0] = regAddr & 0xFF; //LB Addr

    if (!I2C_transfer(handle, &i2cTransaction)) {
        GPIO_write(Board_LED_RED, Board_LED_ON);
        System_abort("Bad I2C transfer!");
    }
}*/

