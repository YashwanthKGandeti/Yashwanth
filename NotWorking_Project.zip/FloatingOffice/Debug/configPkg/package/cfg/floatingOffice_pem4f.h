/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-B24
 */

#include <xdc/std.h>

#include <ti/sysbios/knl/Swi.h>
extern const ti_sysbios_knl_Swi_Handle upButton;

#include <ti/sysbios/knl/Swi.h>
extern const ti_sysbios_knl_Swi_Handle downButton;

#include <ti/sysbios/knl/Task.h>
extern const ti_sysbios_knl_Task_Handle current;

#include <ti/sysbios/knl/Semaphore.h>
extern const ti_sysbios_knl_Semaphore_Handle IMUSem;

#include <ti/sysbios/knl/Semaphore.h>
extern const ti_sysbios_knl_Semaphore_Handle PWMSem;

#include <ti/sysbios/knl/Semaphore.h>
extern const ti_sysbios_knl_Semaphore_Handle Test;

#include <ti/sysbios/knl/Clock.h>
extern const ti_sysbios_knl_Clock_Handle imuClockHandle;

#include <ti/sysbios/knl/Clock.h>
extern const ti_sysbios_knl_Clock_Handle pwmClockHandle;

extern int xdc_runtime_Startup__EXECFXN__C;

extern int xdc_runtime_Startup__RESETFXN__C;

