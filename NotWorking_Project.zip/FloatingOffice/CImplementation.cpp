/*
 * CImplementation.cpp
 *
 *  Created on: 29-Oct-2018
 *      Author: Yashwanth Kumar Gandeti
 */
#include <ti/drivers/PWM.h>
#include <CImplementation.h>
/*#include "CSupport.h"*/
#include "CImu.h"
#include "CCurrent.h"


extern "C"
{
void upButtonSwi();
void downButtonSwi();
void implementation();
void get_current(); // Gets Current from sensor
void get_height();
void get_imu();     // Gets IMU data from sensor
void pwm_generation();//TODO: For test purpose -- delete later

/* Clocking functions used to get the tasks run at specified time in SWI Context
 * All these functions are linked to respective handles of clock module in TI-RTOS .cfg file*/
void imuClock(); // For imu Clocking - every 5 ms
void currentClock(); // For currrent sensor Clocking - every 5 ms
void pwmClock();  // For pwm Clocking -10 ms

}

CGlobal signal;

void upButtonSwi(){
    Semaphore_post(Test);
}
void downButtonSwi(){

}

/*This function is Configured under "ImuClockHandle" module of TI-RTOS which will fires an interrupt for every 5 ms
 * and imuClock() will posts "IMUSem" Semaphore for get_imu() task running
 */
void imuClock(){
    Semaphore_post(IMUSem);
}
/*void currentClock(){
    Semaphore_post(CURRENTSem);
}*/
void pwmClock(){
    Semaphore_post(PWMSem);
}

void implementation(){

}


void writeRegister(I2C_Handle handle, uint8_t regAddr, uint16_t value)
{
    uint8_t             txBuffer[4];
    I2C_Transaction     i2cTransaction;

    i2cTransaction.slaveAddress = 0x41;
    //i2cTransaction.slaveAddress = IMU_Addr;

     //Write to a 16-bit status register

    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 3;
    i2cTransaction.readCount = 0;

    txBuffer[0] = regAddr ; // 8- Bit address
    txBuffer[1] = value >> 8; // HB Addr
    txBuffer[2] = value & 0x00FF; // LB Addr

   /* i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 2;
    i2cTransaction.readCount = 0;

    txBuffer[0] = regAddr & 0xFF; //LB Addr
    txBuffer[1] = value & 0xFF;*/

    if (!I2C_transfer(handle, &i2cTransaction)) {
        GPIO_write(Board_LED_RED, Board_LED_ON);
        System_abort("Bad I2C transfer!");
    }
}
void readRegister(I2C_Handle handle,
                  uint16_t regAddr,
                  uint16_t *data,
                  size_t   length)
{
    uint8_t             txBuffer[2];
    I2C_Transaction     i2cTransaction;

    i2cTransaction.slaveAddress = 0x41;

    //i2cTransaction.slaveAddress = IMU_Addr;

     //Write to a 16-bit status register
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.readBuf = data;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readCount = length;

    txBuffer[0] = regAddr & 0xFF; //LB Addr

    if (!I2C_transfer(handle, &i2cTransaction)) {
        GPIO_write(Board_LED_RED, Board_LED_ON);
        System_abort("Bad I2C transfer!");
    }
}


 /*  ======== taskFxn ========
 *  Task for this function is created statically. See the project's .cfg file. */

Void get_current()
{
    I2C_Handle i2c;
    I2C_Params i2cParams;
    uint16_t rec;

     //Create I2C for usage
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_100kHz;
    i2c = I2C_open(INA_I2C, &i2cParams);
    if (i2c == NULL)
    {
        System_abort("Error Initializing I2C\n");
    }
    else
    {
        System_printf("I2C Initialized!\n");
    }
    // set calibiration register for CALCULATED VALUE
    writeRegister(i2c,0x05, 8192);
    uint16_t config = 15455;
    // Set config register to required configuration
    writeRegister(i2c, 0x00, config);

    writeRegister(i2c,0x6B, 0x80);

   while(1)
    {
       Semaphore_pend(Test,BIOS_WAIT_FOREVER);
       readRegister(i2c, 0x01, &rec, 2);
    }

     //Deinitialized I2C
    I2C_close(i2c);
    System_printf("I2C closed!\n");
    System_flush();

}


void get_height(){


}

void get_imu()
{
    I2C_Handle i2c;
    I2C_Params i2cParams;
    uint16_t pwr = 0x00;
    CSupport support;
    //Create I2C for usage
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;
    /*i2c = I2C_open(IMU_SENSOR,&i2cParams);*/
    if (i2c == NULL)
    {
        System_abort("Error Initializing I2C\n");
    }
    else
    {
        System_printf("I2C Initialized!\n");
    }
    // Initialize the MPU6050
    support.i2c_writeRegister(i2c,MPU6050_I2C_ADDRESS,0x6B,0x80,IMU_TRANSACTION);
    support.i2c_readRegister(i2c,MPU6050_I2C_ADDRESS, 0x6B, &pwr, 1, IMU_TRANSACTION);
    do
    {
        support.i2c_readRegister(i2c,MPU6050_I2C_ADDRESS, 0x6B, &pwr, 1, IMU_TRANSACTION);
    }
    while ((pwr & 0x40) != 0x40);

    // Use PLL with X axis gyroscope reference
    support.i2c_writeRegister(i2c,MPU6050_I2C_ADDRESS,0x6B,0x01,IMU_TRANSACTION);
    // Enable I2C Master mode
    support.i2c_writeRegister(i2c,MPU6050_I2C_ADDRESS,0x6A,0x20,IMU_TRANSACTION);
    // Set sample rate divider
    support.i2c_writeRegister(i2c,MPU6050_I2C_ADDRESS,0x19,0x13,IMU_TRANSACTION);
    support.i2c_writeRegister(i2c,MPU6050_I2C_ADDRESS,0x67,0x11,IMU_TRANSACTION);
    while (1)
    {
        /*Semaphore_pend(IMUSem, BIOS_WAIT_FOREVER);*/
        support.i2c_readRegister(i2c,MPU6050_I2C_ADDRESS, 0x3B, (uint16_t *) &signal.imu.mpu6050, 14, IMU_TRANSACTION);
    }

    I2C_close(i2c);  //Deinitialized I2C
    System_printf("I2C closed!\n");
    System_flush();
}


void pwm_generation()
{
    PWM_Handle pwm1;
    PWM_Handle pwm2 = NULL;
    PWM_Params params;
    uint32_t   pwmPeriod = 50;      // Period and duty in microseconds
    uint16_t   duty = 0;
    uint16_t   dutyInc = 1;

    PWM_Params_init(&params);
    params.period = pwmPeriod;
    pwm1 = PWM_open(Board_PWM0, &params);
    if (pwm1 == NULL) {
        System_abort("Board_PWM0 did not open");
    }

    if (Board_PWM1 != Board_PWM0) {
        params.polarity = PWM_POL_ACTIVE_LOW;
        pwm2 = PWM_open(Board_PWM1, &params);
        if (pwm2 == NULL) {
            System_abort("Board_PWM1 did not open");
        }
    }

    /* Loop forever incrementing the PWM duty */
    while (1) {
        Semaphore_pend(PWMSem, BIOS_WAIT_FOREVER);
        PWM_setDuty(pwm1, duty);
        if (pwm2) {
            PWM_setDuty(pwm2, duty);
        }

        duty = (duty + dutyInc);
        if (duty == pwmPeriod || (!duty)) {
            dutyInc = - dutyInc;
        }
    }
}
