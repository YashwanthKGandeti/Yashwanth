/*
 * CVertical.cpp
 *
 *  Created on: 28-Aug-2018
 *      Author: gyk31
 */

#include <CVertical.h>
#include "inc/hw_gpio.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
CVertical::CVertical(){

}
CVertical::CVertical(double kp, double ki,float intHeight)
{
    this->speedKp = kp;
    this->speedKi = ki;
    this->vertIntHeight = intHeight;
}
void CVertical::initVertical(double kp, double ki,float intHeight)
{
    this->speedKp = kp;
    this->speedKi = ki;
    this->vertIntHeight = intHeight;
}


void verticalInit()
{
    /****************************************Front Motor******************************************/
    //
    // Configure the GPIO Pin Mux for PB0
    // for GPIO_PB0
    //
    GPIOPinTypeGPIOInput(GPIO_PORTB_BASE, GPIO_PIN_0);
    GPIOPadConfigSet(GPIO_PORTB_BASE, GPIO_PIN_0, GPIO_STRENGTH_2MA,
                         GPIO_PIN_TYPE_STD_WPU);


    //
    // Configure the GPIO Pin Mux for PE3
    // for GPIO_PE3 - FRONT MOTOR HALL SENSOR CHANNEL B
    //
    GPIOPinTypeGPIOInput(GPIO_PORTE_BASE, GPIO_PIN_3);
    GPIOPadConfigSet(GPIO_PORTE_BASE, GPIO_PIN_3, GPIO_STRENGTH_2MA,
                     GPIO_PIN_TYPE_STD_WPU);

    //
    // Configure the GPIO Pin Mux for PE2
    // for GPIO_PE2 - PINB
    //
    GPIOPinTypeGPIOOutput(GPIO_PORTE_BASE, GPIO_PIN_2);
    GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_2, GPIO_PIN_2);

    //
    // Configure the GPIO Pin Mux for PE1
    // for GPIO_PE1 - PINA
    //
    GPIOPinTypeGPIOOutput(GPIO_PORTE_BASE, GPIO_PIN_1);
    GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_1, GPIO_PIN_1);

    //
    // Configure the GPIO Pin Mux for PB6
    // for M0PWM0 - FRONT MOTOR PWM
    //
    GPIOPinConfigure(GPIO_PB6_M0PWM0);
    GPIOPinTypePWM(GPIO_PORTB_BASE, GPIO_PIN_6);

    /****************************************Back Motor******************************************/

    //
    // Configure the GPIO Pin Mux for PE0
    // for GPIO_PE0 - Back MOTOR HAll input Channel A
    //
    GPIOPinTypeGPIOInput(GPIO_PORTE_BASE, GPIO_PIN_0);
    GPIOPadConfigSet(GPIO_PORTE_BASE, GPIO_PIN_0, GPIO_STRENGTH_2MA,
                     GPIO_PIN_TYPE_STD_WPU);

    //
    // Unlock the Port Pin and Set the Commit Bit
    //
    HWREG(GPIO_PORTD_BASE+GPIO_O_LOCK) = GPIO_LOCK_KEY;
    HWREG(GPIO_PORTD_BASE+GPIO_O_CR) |= GPIO_PIN_7;
    HWREG(GPIO_PORTD_BASE+GPIO_O_LOCK) = 0x0;

    //
    // Configure the GPIO Pin Mux for PD7
    // for GPIO_PD7 - Back MOTOR HAll input Channel A
    //
    GPIOPinTypeGPIOInput(GPIO_PORTD_BASE, GPIO_PIN_7);
    GPIOPadConfigSet(GPIO_PORTD_BASE, GPIO_PIN_7, GPIO_STRENGTH_2MA,
                     GPIO_PIN_TYPE_STD_WPU);

    //
    // Configure the GPIO Pin Mux for PC7
    // for GPIO_PC7
    //
    GPIOPinTypeGPIOOutput(GPIO_PORTC_BASE, GPIO_PIN_7);
    GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_7, GPIO_PIN_7);

    //
    // Configure the GPIO Pin Mux for PC6
    // for GPIO_PC6
    //
    GPIOPinTypeGPIOOutput(GPIO_PORTC_BASE, GPIO_PIN_6);
    GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_6, GPIO_PIN_6);

    //
    // Configure the GPIO Pin Mux for PB7
    // for M0PWM1 - Back MOTOR PWM
    //
    GPIOPinConfigure(GPIO_PB7_M0PWM1);
    GPIOPinTypePWM(GPIO_PORTB_BASE, GPIO_PIN_7);

}
