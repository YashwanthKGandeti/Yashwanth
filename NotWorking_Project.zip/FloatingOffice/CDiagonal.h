/*
 * CDiagonal.h
 *
 *  Created on: 28-Aug-2018
 *      Author: gyk31
 */

#ifndef CDIAGONAL_H_
#define CDIAGONAL_H_
#include <xdc/std.h>
#include "Board.h"
/*#include "CSupport.h"*/

#define BASE_1  640.0
#define BASE_2  670.0
#define BASE_3  1425.0

#define VERTICAL_FRONT_SPEED_KP 1.5
#define VERTICAL_FRONT_SPEED_KI 11
#define VERTICAL_FRONT_SPEED_KD 0   // Can be used in future for fine tuning of front motor speed

#define VERTICAL_BACK_SPEED_KP 1.5
#define VERTICAL_BACK_SPEED_KI 11
#define VERTICAL_BACK_SPEED_KD 0    // Can be used in future for fine tuning of back motor speed

#define DIAGONAL_SPEED_KP 2.0
#define DIAGONAL_SPEED_KI 20.0
#define DIAGONAL_SPEED_KD 2

#define DIAGONAL_POSITION_KP 2.0
#define DIAGONAL_POSITION_KI 0.0
#define DIAGONAL_POSITION_KD 0.0

#define DIAGONAL_CURRENT_KP 0.3
#define DIAGONAL_CURRENT_KI 0.7
#define DIAGONAL_CURRENT_KD 0.0

#define DIAGONAL_TIGHTENING_KP 1.0
#define DIAGONAL_TIGHTENING_KI 5.0
#define DIAGONAL_TIGHTENING_KD 0.0


class CDiagonal
{
public:

    // Speed parameters
    float rpm;
    float rpmFilt;

    // Current Parameters
    float curr;
    float currFiltered;

    // Postion Parameters

    int16_t encPos;
    int16_t encPosOld;
    int16_t encPosOffset;

    // speed PID Controller Params
    double speedKp;
    double speedKi;
    double speedKd;
    double speedSetpoint;
    double speedInput;
    double speedOutput;

    // Position PID Controller Params
    double positionKp;
    double positionKi;
    double positionKd;
    double positionSetpoint;
    double positionInput;
    double positionOutput;

    // Current PID Controller Params
    double currentKp;
    double currentKi;
    double currentKd;
    double currentSetpoint;
    double currentInput;
    double currentOutput;

    // For diagonal tightening (without moving the desk up/down) PID Controller Params
    double tensionKp;
    double tensionKi;
    double tensionKd;
    double tensionSetpoint;
    double tensionInput;
    double tensionOutput;

    float h;    // Update diagonal height in mm
    float h_0;  // intial vertical height in mm before start
    float Offset;

    /* Arrays for the lengths of the diagonals
    for 3m, whereby each displaced mm vertical height corresponds to the index*/
    /*float a1[3000]; //Diagonal motor(BLDC) 1
    float a2[10]; //Diagonal motor(BLDC) 2
    float a3[10]; //Diagonal motor(BLDC) 3
    float a4[10]; //Diagonal motor(BLDC) 4
    float a5[10]; //Diagonal motor(BLDC) 5
    float a6[10]; //Diagonal motor(BLDC) 6*/

public:
    CDiagonal(); //Default constructor
    CDiagonal(float height,float base);
    CDiagonal(float base);
    void initDiagonal(float height,float base);

};
extern "C" void diagonalInit();
extern "C" void i2cInit();

#endif /* CDIAGONAL_H_ */
