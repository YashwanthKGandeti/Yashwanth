/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-B06
 */

#ifndef xconfig_i2ctmp006__
#define xconfig_i2ctmp006__



#endif /* xconfig_i2ctmp006__ */ 
