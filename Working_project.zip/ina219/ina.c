/*
 * Copyright (c) 2015, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *    ======== i2crf430cl330_load.c ========
 */

/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Log.h>                //needed for any Log_info() call
#include <xdc/cfg/global.h>                 //header file for statically defined objects/handles
#include <xdc/runtime/Timestamp.h>          //for timestampping

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/utils/Load.h>

/* TI-RTOS Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/I2C.c>
#include <ti/drivers/PWM.h>

#include <ti/drivers/i2c/I2CTiva.c>
#include <inc/hw_memmap.h>
#include <driverlib/gpio.h>
//#include <driverlib/i2c.h>
#include "driverlib/sysctl.h"


/* Example/Board Header files */
#include "Board.h"

#include <stdio.h>
#include <stdlib.h>

#define CURR_I2C_ADDR       0x41
#define IMU_Addr            0x68


void writeRegister(I2C_Handle handle, uint8_t regAddr, uint16_t value)
{
    uint8_t             txBuffer[4];
    I2C_Transaction     i2cTransaction;

    i2cTransaction.slaveAddress = CURR_I2C_ADDR;
    /*i2cTransaction.slaveAddress = IMU_Addr;*/

     //Write to a 16-bit status register

    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 3;
    i2cTransaction.readCount = 0;

    txBuffer[0] = regAddr ; // 8- Bit address
    txBuffer[1] = value >> 8; // HB Addr
    txBuffer[2] = value & 0xFF; // LB Addr

/*  i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 2;
    i2cTransaction.readCount = 0;

    txBuffer[0] = regAddr & 0xFF; //LB Addr
    txBuffer[1] = value & 0xFF;*/

    if (!I2C_transfer(handle, &i2cTransaction)) {
        GPIO_write(Board_LED2, Board_LED_ON);
        System_abort("Bad I2C transfer!");
    }
}
void readRegister(I2C_Handle handle,
                  uint16_t regAddr,
                  uint16_t *data,
                  size_t   length)
{
    uint8_t             txBuffer[2];
    I2C_Transaction     i2cTransaction;

    i2cTransaction.slaveAddress = CURR_I2C_ADDR;

    /*i2cTransaction.slaveAddress = IMU_Addr;*/

    /* Write to a 16-bit status register */
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.readBuf = data;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readCount = length;

    txBuffer[0] = regAddr & 0xFF; //LB Addr

    if (!I2C_transfer(handle, &i2cTransaction)) {
        GPIO_write(Board_LED2, Board_LED_ON);
        System_abort("Bad I2C transfer!");
    }
}

/*
 *  ======== taskFxn ========
 *  Task for this function is created statically. See the project's .cfg file.
 */
Void currentTask()
{
    I2C_Handle i2c;
    I2C_Params i2cParams;
    uint16_t rec;

    /* Create I2C for usage */
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_100kHz;
    i2c = I2C_open(INA_I2C, &i2cParams);
    if (i2c == NULL)
    {
        System_abort("Error Initializing I2C\n");
    }
    else
    {
        System_printf("I2C Initialized!\n");
    }
    // set calibiration register for CALCULATED VALUE
    writeRegister(i2c,0x05, 8192);
    uint16_t config = 15455;
    // Set config register to required configuration
    writeRegister(i2c, 0x00, config);

    /*writeRegister(i2c,0x6B, 0x80);*/

   while(1)
    {
       Semaphore_pend(Test,BIOS_WAIT_FOREVER);
       readRegister(i2c, 0x01, &rec, 2);
    }

    /* Deinitialized I2C */
    I2C_close(i2c);
    System_printf("I2C closed!\n");
    System_flush();

}
/*  Callback function for the GPIO interrupt on up Button.*/
void gpioButtonFxn1(unsigned int index)
{
    Semaphore_post(Test);
}
void pwmClock(){
    Semaphore_post(PWMSem);

}

/*void readClock(){
    Semaphore_post(Test);
}*/
/*
 *  ======== main ========
 */
int main(void)
{
    Task_Params taskParams;

    /* Call board init functions */
    Board_initGeneral();
    Board_initGPIO();
    Board_initPWM();
    // Check that I2C SDA is not being held low
    // If so, toggle I2C SCL until it is released
    GPIOPinTypeGPIOInput(GPIO_PORTD_BASE, GPIO_PIN_1);
    GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_0);
    while(GPIOPinRead(GPIO_PORTD_BASE, GPIO_PIN_1) != GPIO_PIN_1)
    {
        GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_0, 0);
        GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_0, GPIO_PIN_0);
    }

    Board_initI2C();

    SysCtlClockSet(SYSCTL_SYSDIV_4|SYSCTL_USE_PLL|SYSCTL_XTAL_16MHZ|
                    SYSCTL_OSC_MAIN);
    System_flush();
    /* install Button callback */
    GPIO_setCallback(Board_BUTTON0, gpioButtonFxn1);

    /* Enable interrupts */
    GPIO_enableInt(Board_BUTTON0);

    System_printf("Starting the I2C example\nSystem provider is set to SysMin."
                  " Halt the target to view any SysMin contents in ROV.\n");
    /* SysMin will only print to the console when you call flush or exit */
    System_flush();

    /* Start BIOS */
    BIOS_start();

    return (0);
}

void pwm_generation()
{
    PWM_Handle pwm1;
    PWM_Handle pwm2 = NULL;
    PWM_Params params;
    uint32_t   pwmPeriod = 50;      // Period and duty in microseconds
    uint16_t   duty = 0;
    uint16_t   dutyInc = 1;

    PWM_Params_init(&params);
    params.period = pwmPeriod;
    pwm1 = PWM_open(Board_PWM0, &params);
    if (pwm1 == NULL) {
        System_abort("Board_PWM0 did not open");
    }

    if (Board_PWM1 != Board_PWM0) {
        params.polarity = PWM_POL_ACTIVE_LOW;
        pwm2 = PWM_open(Board_PWM1, &params);
        if (pwm2 == NULL) {
            System_abort("Board_PWM1 did not open");
        }
    }

    /* Loop forever incrementing the PWM duty */
    while (1) {
        Semaphore_pend(PWMSem, BIOS_WAIT_FOREVER);
        PWM_setDuty(pwm1, duty);
        if (pwm2) {
            PWM_setDuty(pwm2, duty);
        }

        duty = (duty + dutyInc);
        if (duty == pwmPeriod || (!duty)) {
            dutyInc = - dutyInc;
        }
    }
}
